def return_phone_number():
    return '555-1212'

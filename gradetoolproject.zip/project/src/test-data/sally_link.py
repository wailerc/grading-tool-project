def return_phone_number():
    return '818-534-9875'
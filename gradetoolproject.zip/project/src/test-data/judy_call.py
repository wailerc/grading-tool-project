def return_phone_number():
    return '888-555-1212'

def return_phone_number():
    return '323-123-4567'
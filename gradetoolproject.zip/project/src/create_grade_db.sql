/* ---------- create gradetooldb database */

DROP DATABASE IF EXISTS gradetooldb;

CREATE DATABASE gradetooldb;

USE gradetooldb;

/* ---------- create name table */

CREATE TABLE     tblStudents(
nameid           int not null,
name             varchar(64),
PRIMARY KEY      (nameid)
)                ENGINE=InnoDB;

/* ---------- create score table */

CREATE TABLE     tblScores(
scoreid          int not null,
score            int,
PRIMARY KEY      (scoreid)
)                ENGINE=InnoDB;

/* ---------- create feedback table */

CREATE TABLE     tblFeedback(
feedbackid       int not null,
feedback         varchar(64),
PRIMARY KEY      (feedbackid)
)                ENGINE=InnoDB;

DESCRIBE gradetooldb.tblStudents;
DESCRIBE gradetooldb.tblScores;
DESCRIBE gradetooldb.tblFeedback;
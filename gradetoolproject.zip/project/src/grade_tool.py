#!\\user\bin\python
#=========================================================
#
#=========================================================

import pymysql
import re
import os
import sys

directory = './test-data/'            # must end in '/'

regexp    = r'\.py$'        # file name regular expression pattern

phone_regexp = (re.compile(r'^\d\d\d-\d\d\d-\d\d\d\d$'))

# -------------------------------------------------------------------
# get a list of files that match a given regular expression
# -------------------------------------------------------------------

def get_list_of_files(dir,pat):

    files = []

    # --- get a list of entries in the directory

    dir_files = os.listdir(dir)

    # ---- skip all entries that are not regular files and files that
    # ---- do not match the regexp pattern

    for f in dir_files:

        ff = dir + f

        if os.path.islink(ff):
            continue

        if not os.path.isfile(ff):
            continue
       
        if re.search(pat,f):
            files.append(f)

    files.sort()                # sort the returned list

    return files

def insert_into_db(conn, cur, id, student_name, score, feedback):
    try:
        # insert to tblStudents
        sql = f'''INSERT INTO tblStudents (nameid, name)
             VALUES ({id}, "{student_name}")'''      
        cur.execute(sql)
        # insert to tblScores
        sql = f'''INSERT INTO tblScores (scoreid,score)
             VALUES ({id}, {score})'''      
        cur.execute(sql)
        # insert to tblFeedback
        sql = f'''INSERT INTO tblFeedback (feedbackid, feedback)
             VALUES ({id}, "{feedback}")'''      
        cur.execute(sql)
        conn.commit()
    except Exception as e:
        print(f'Exception occurred: {e}')
        cur.close()
        conn.close()
        sys.exit()
        
def modify_feedback(conn, cur, id, feedback):
    try:
        sql = f'''update tblFeedback
            set feedback = '{feedback}'
            where feedbackid = {id}'''
        cur.execute(sql)            
        conn.commit()
    except Exception as e:
        print(f'Exception occurred: {e}')
        cur.close()
        conn.close()
        sys.exit()
    
    
#----------------------------------------------------------------
# main
#---------------------------------------------------------------

#create DB connection and cursor

conn = pymysql.connect(host='localhost',
                       user='root',
                       password='Tom',
                       database='gradetooldb',
                       charset='utf8')

cur = conn.cursor()


files = get_list_of_files(directory,regexp)

good_phone_list = []

id = 1001


for f in files:

    x = f.split('.')
    student_name = x[0].replace('_', ' ' )
    
    
    fpath = directory+f
    #print(fpath)
    
    ff = open(fpath)
    s = ff.read()
    ff.close()
    
    exec(s)
        

    ph = return_phone_number()

    #print(ph)

    m = phone_regexp.match(ph)

    if m is None:
        print(f'insert {id}, {student_name}, {ph}, "Incorrect Format"')
        insert_into_db(conn, cur, id, student_name, 0, "Incorrect Format")
    else:
        good_phone_list.append((id, ph))
        print(f'insert {id}, {student_name}, {ph}, "Good Job"')
        insert_into_db(conn, cur, id, student_name, 1, "Good Job")    
        

    id += 1

good_phone_list.sort(key=lambda a:a[1])


for i in range(len(good_phone_list) - 1):
    ph1 = good_phone_list[i][1]
    ph2 = good_phone_list[i+ 1][1]

    id1 = good_phone_list[i][0]
    id2 = good_phone_list[i+ 1][0]

    if ph1 == ph2:
        print(f'modify id={id1} Feedback = "Plagarism Detected"')
        print(f'modify id={id2} Feedback = "Plagarism Detected"')
        modify_feedback(conn, cur, id1, "Plagarism Detected")
        modify_feedback(conn, cur, id2, "Plagarism Detected")

        

    

    








     

    






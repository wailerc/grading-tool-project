1. Based on the description of the project, a multi-table 
   relational database is not required. There are only 
   three tables because it is specified by the project requirements. 

2. The executable is a Python script in the src folder

3. The Design is psuedo code in the design folder

4. The test files are in the src/test-data folder

5. The SQL files do:
 5.1 create/initialize the database and define its schema
 5.2 adds an anonymous read-only account for teachers

6. mysql.bat runs mysql command-line tool and uses the *.sql files


   

